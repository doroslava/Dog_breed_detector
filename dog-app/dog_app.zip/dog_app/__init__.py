from flask import Flask

app = Flask(__name__)

from dog_app import routes